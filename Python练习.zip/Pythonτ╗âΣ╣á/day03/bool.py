# int --> str
i = 1
s = str(i)


# str --> int
s = '123'
i = int(s)
print(i, type(i))


# int ---》 bool
i = 3
b = bool(i)
print(b)