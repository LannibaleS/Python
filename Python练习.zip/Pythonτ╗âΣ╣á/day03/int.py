i = 100 
# 转化成2进制的最小位数
print(i.bit_length())